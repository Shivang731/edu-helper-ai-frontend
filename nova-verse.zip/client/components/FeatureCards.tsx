import {
  FileText,
  CreditCard,
  Volume2,
  Search,
  Play,
  Pause,
  ArrowRight,
} from "lucide-react";
import { useState } from "react";

interface FeatureCard {
  title: string;
  description: string;
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
  iconColor: string;
  demoContent?: string;
  action?: string;
}

const features: FeatureCard[] = [
  {
    title: "Smart Summaries",
    description:
      "AI-generated summaries that capture key concepts and main ideas from your documents.",
    icon: FileText,
    iconColor: "bg-blue-100 text-blue-600",
    demoContent:
      "This is an AI-generated summary of your document showing the key points and main concepts...",
    action: "Generate Summary",
  },
  {
    title: "Flashcards",
    description:
      "Automatically generated question-answer pairs for effective spaced repetition learning.",
    icon: CreditCard,
    iconColor: "bg-green-100 text-green-600",
    demoContent:
      "Q: What is the main concept? A: The primary idea discussed in the document...",
    action: "Create Flashcards",
  },
  {
    title: "Audio Narration",
    description:
      "Listen to your summaries with high-quality text-to-speech conversion.",
    icon: Volume2,
    iconColor: "bg-purple-100 text-purple-600",
    demoContent: "🔊 Playing audio narration of your study material...",
    action: "Play Audio",
  },
  {
    title: "Smart Search",
    description:
      "Semantic search through your processed documents with context-aware results.",
    icon: Search,
    iconColor: "bg-orange-100 text-orange-600",
    demoContent:
      "Search results: Found 3 relevant sections matching your query...",
    action: "Search Documents",
  },
];

export function FeatureCards() {
  const [activeDemo, setActiveDemo] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const handleDemo = (title: string) => {
    if (title === "Audio Narration") {
      if (isPlaying) {
        // Stop current speech
        window.speechSynthesis.cancel();
        setIsPlaying(false);
      } else {
        // Start speech synthesis
        const text =
          "Welcome to Study Aid Generator. This is a demonstration of our text-to-speech feature that can read your study materials aloud, making learning more accessible and convenient.";

        if ("speechSynthesis" in window) {
          const utterance = new SpeechSynthesisUtterance(text);
          utterance.rate = 0.9;
          utterance.pitch = 1;
          utterance.volume = 0.8;

          utterance.onstart = () => setIsPlaying(true);
          utterance.onend = () => setIsPlaying(false);
          utterance.onerror = () => {
            setIsPlaying(false);
            alert(
              "Sorry, text-to-speech is not supported in your browser or failed to start.",
            );
          };

          window.speechSynthesis.speak(utterance);
        } else {
          alert("Text-to-speech is not supported in your browser.");
        }
      }
    } else {
      setActiveDemo(activeDemo === title ? null : title);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {features.map((feature) => (
        <div
          key={feature.title}
          className="rounded-xl border border-border bg-card p-6 hover:shadow-md transition-all duration-200 hover:-translate-y-1"
        >
          <div
            className={`inline-flex rounded-lg p-3 ${feature.iconColor} mb-4`}
          >
            <feature.icon className="h-6 w-6" />
          </div>
          <h3 className="text-lg font-semibold text-card-foreground mb-2">
            {feature.title}
          </h3>
          <p className="text-sm text-muted-foreground leading-relaxed mb-4">
            {feature.description}
          </p>

          {/* Demo Button */}
          <button
            onClick={() => handleDemo(feature.title)}
            className="inline-flex items-center gap-2 text-xs font-medium text-primary hover:text-primary/80 transition-colors"
          >
            {feature.title === "Audio Narration" ? (
              isPlaying ? (
                <Pause className="h-3 w-3" />
              ) : (
                <Play className="h-3 w-3" />
              )
            ) : (
              <ArrowRight className="h-3 w-3" />
            )}
            {feature.title === "Audio Narration"
              ? isPlaying
                ? "Pause"
                : "Try Demo"
              : "Try Demo"}
          </button>

          {/* Demo Content */}
          {activeDemo === feature.title && feature.demoContent && (
            <div className="mt-3 p-3 bg-muted rounded-lg">
              <p className="text-xs text-muted-foreground">
                Demo: {feature.demoContent}
              </p>
            </div>
          )}

          {/* Audio Playing Indicator */}
          {feature.title === "Audio Narration" && isPlaying && (
            <div className="mt-3 p-3 bg-purple-50 dark:bg-purple-950/20 rounded-lg">
              <div className="flex items-center gap-2">
                <div className="flex space-x-1">
                  <div className="w-1 h-3 bg-purple-500 rounded-full animate-pulse"></div>
                  <div className="w-1 h-3 bg-purple-500 rounded-full animate-pulse delay-75"></div>
                  <div className="w-1 h-3 bg-purple-500 rounded-full animate-pulse delay-150"></div>
                </div>
                <p className="text-xs text-purple-700 dark:text-purple-300">
                  Playing audio narration...
                </p>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
