import {
  Upload,
  FileText,
  CheckCircle,
  X,
  Loader2,
  AlertCircle,
} from "lucide-react";
import { useRef, useState } from "react";
import { cn } from "@/lib/utils";

interface DocumentUploadProps {
  className?: string;
}

interface ProcessedFile {
  name: string;
  size: string;
  type: string;
  status: "processing" | "completed";
  summary?: string;
  flashcards?: number;
}

export function DocumentUpload({ className }: DocumentUploadProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const [files, setFiles] = useState<ProcessedFile[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const droppedFiles = Array.from(e.dataTransfer.files);
    handleFiles(droppedFiles);
  };

  const handleFileSelect = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    handleFiles(selectedFiles);
    e.target.value = ""; // Reset input
  };

  const handleFiles = (fileList: File[]) => {
    const validTypes = [".pdf", ".txt", ".docx", ".md"];
    const validFiles = fileList.filter((file) => {
      const extension = "." + file.name.split(".").pop()?.toLowerCase();
      return validTypes.includes(extension) && file.size <= 50 * 1024 * 1024; // 50MB limit
    });

    if (validFiles.length === 0) {
      alert("Please upload valid files: PDF, TXT, DOCX, or MD (max 50MB each)");
      return;
    }

    setIsProcessing(true);

    validFiles.forEach((file) => {
      const newFile: ProcessedFile = {
        name: file.name,
        size: (file.size / 1024 / 1024).toFixed(1) + " MB",
        type: file.type || "Unknown",
        status: "processing",
      };

      setFiles((prev) => [...prev, newFile]);

      // Simulate processing
      setTimeout(
        () => {
          setFiles((prev) =>
            prev.map((f) =>
              f.name === file.name
                ? {
                    ...f,
                    status: "completed",
                    summary: `Generated summary for ${file.name.split(".")[0]}`,
                    flashcards: Math.floor(Math.random() * 15) + 5,
                  }
                : f,
            ),
          );
          setIsProcessing(false);
        },
        2000 + Math.random() * 2000,
      );
    });
  };

  const removeFile = (fileName: string) => {
    setFiles((prev) => prev.filter((f) => f.name !== fileName));
  };

  return (
    <div className={cn("w-full", className)}>
      {/* Upload Area */}
      <div
        className={cn(
          "relative flex flex-col items-center justify-center rounded-xl border-2 border-dashed border-border bg-muted/30 p-8 md:p-16 transition-colors",
          isDragOver && "border-primary bg-primary/5",
        )}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <div className="flex flex-col items-center space-y-4">
          <div className="rounded-full bg-muted p-3 md:p-4">
            <Upload className="h-6 w-6 md:h-8 md:w-8 text-muted-foreground" />
          </div>
          <div className="text-center space-y-2">
            <h3 className="text-base md:text-lg font-medium">
              Drag & Drop your document here
            </h3>
            <p className="text-xs md:text-sm text-muted-foreground">
              or click to browse from your computer
            </p>
          </div>
          <button
            onClick={handleFileSelect}
            disabled={isProcessing}
            className={cn(
              "rounded-lg px-4 md:px-6 py-2 text-xs md:text-sm font-medium transition-colors",
              isProcessing
                ? "bg-muted text-muted-foreground cursor-not-allowed"
                : "bg-primary text-primary-foreground hover:bg-primary/90",
            )}
          >
            {isProcessing ? "Processing..." : "Select File"}
          </button>
        </div>
        <input
          ref={fileInputRef}
          type="file"
          className="hidden"
          accept=".pdf,.txt,.docx,.md"
          multiple
          onChange={handleFileChange}
        />
      </div>

      {/* File List */}
      {files.length > 0 && (
        <div className="mt-6 space-y-3">
          <h4 className="text-sm font-medium text-foreground">
            Uploaded Files
          </h4>
          {files.map((file) => (
            <div
              key={file.name}
              className="flex items-center justify-between p-4 bg-background border border-border rounded-lg"
            >
              <div className="flex items-center space-x-3">
                <div className="flex-shrink-0">
                  {file.status === "processing" ? (
                    <Loader2 className="h-4 w-4 animate-spin text-primary" />
                  ) : (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">
                    {file.name}
                  </p>
                  <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                    <span>{file.size}</span>
                    {file.status === "completed" && file.flashcards && (
                      <>
                        <span>•</span>
                        <span>{file.flashcards} flashcards generated</span>
                      </>
                    )}
                  </div>
                </div>
              </div>
              <button
                onClick={() => removeFile(file.name)}
                className="flex-shrink-0 p-1 text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
