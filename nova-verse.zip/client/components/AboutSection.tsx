import { Github, Instagram, Mail } from "lucide-react";

export function AboutSection() {
  return (
    <div className="py-12 bg-muted/30">
      <div className="mx-auto max-w-4xl px-4 md:px-8">
        {/* Supported File Formats */}
        <div className="bg-background rounded-xl border border-border p-6 mb-8">
          <h3 className="text-lg font-semibold text-foreground mb-4">
            Supported File Formats
          </h3>
          <div className="flex flex-wrap gap-3 mb-4">
            <span className="px-3 py-1 bg-muted text-muted-foreground text-sm rounded-md font-mono">
              .pdf
            </span>
            <span className="px-3 py-1 bg-muted text-muted-foreground text-sm rounded-md font-mono">
              .txt
            </span>
            <span className="px-3 py-1 bg-muted text-muted-foreground text-sm rounded-md font-mono">
              .docx
            </span>
            <span className="px-3 py-1 bg-muted text-muted-foreground text-sm rounded-md font-mono">
              .md
            </span>
          </div>
          <p className="text-sm text-muted-foreground">
            Maximum file size: 500MB. For best results, use well-formatted
            documents with clear structure.
          </p>
        </div>

        {/* About Me */}
        <div className="bg-background rounded-xl border border-border p-6 mb-8">
          <h3 className="text-lg font-semibold text-foreground mb-4">
            About Me
          </h3>
          <div className="space-y-4 text-sm text-muted-foreground leading-relaxed">
            <p>
              Hi, I'm{" "}
              <strong className="text-foreground">Shivang Kumar Dubey</strong>,
              a first-year student at Scaler School of Technology and a
              passionate developer building AI-powered study tools to help
              students learn smarter.
            </p>
            <p>
              My journey in technology began with a fascination for how
              artificial intelligence can transform education. I'm deeply
              passionate about Natural Language Processing, education
              technology, and creating clean, intuitive user experiences that
              make complex tools accessible to everyone.
            </p>
            <p>
              This project represents my commitment to leveraging artificial
              intelligence to democratize education and make learning more
              efficient and engaging for students worldwide. I believe that the
              right tools can unlock every student's potential and make quality
              education accessible to all.
            </p>
            <p>
              When I'm not coding, you can find me exploring new AI research
              papers, contributing to open-source projects, or mentoring fellow
              students in their coding journey.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center">
          <p className="text-sm text-muted-foreground mb-4">
            © 2025 Edu Helper AI. Built with passion for education and
            technology.
          </p>
          <div className="flex justify-center gap-4">
            <a
              href="https://github.com/shivang731"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <Github className="h-5 w-5" />
              <span className="text-sm">shivang731</span>
            </a>
            <a
              href="https://instagram.com/shivang.skd"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <Instagram className="h-5 w-5" />
              <span className="text-sm">shivang.skd</span>
            </a>
            <a
              href="mailto:shivangkumardubey@gmail.com"
              className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <Mail className="h-5 w-5" />
              <span className="text-sm">shivangkumardubey@gmail.com</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
