import { useState } from "react";
import {
  Menu,
  X,
  Search,
  Upload,
  FileText,
  Play,
  Download,
  Settings,
} from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";

const navigation = [
  {
    section: "GET STARTED",
    items: [{ name: "Upload Document", href: "/", icon: Upload }],
  },
  {
    section: "AI TOOLS",
    items: [
      { name: "Summary & Cards", href: "/summary", icon: FileText },
      { name: "Audio Player", href: "/audio", icon: Play },
    ],
  },
  {
    section: "EXPORT",
    items: [
      { name: "Export Options", href: "/export", icon: Download },
      { name: "Settings", href: "/settings", icon: Settings },
    ],
  },
];

export function MobileNav() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const toggleMenu = () => setIsOpen(!isOpen);
  const closeMenu = () => setIsOpen(false);

  return (
    <div className="md:hidden">
      {/* Mobile Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-background border-b border-border">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <FileText className="h-4 w-4" />
          </div>
          <div>
            <h1 className="text-sm font-semibold">Edu Helper AI</h1>
            <p className="text-xs text-muted-foreground">
              Smart Study Generator
            </p>
          </div>
        </div>
        <button
          onClick={toggleMenu}
          className="p-2 rounded-lg hover:bg-muted transition-colors"
        >
          {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <div className="fixed inset-0 z-50 bg-black/50" onClick={closeMenu}>
          <div
            className="fixed left-0 top-0 h-full w-80 bg-background border-r border-border"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-4 py-3 border-b border-border">
              <div className="flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                  <FileText className="h-4 w-4" />
                </div>
                <div>
                  <h1 className="text-sm font-semibold">Edu Helper AI</h1>
                  <p className="text-xs text-muted-foreground">
                    Smart Study Generator
                  </p>
                </div>
              </div>
              <button
                onClick={closeMenu}
                className="p-2 rounded-lg hover:bg-muted transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Search */}
            <div className="px-4 py-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search documents..."
                  className="w-full rounded-lg border border-input bg-background px-10 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      const query = e.currentTarget.value;
                      if (query.trim()) {
                        alert(
                          `Searching for: "${query}"\n\nDemo: This would search through your uploaded documents and show relevant results.`,
                        );
                        e.currentTarget.value = "";
                        closeMenu();
                      }
                    }
                  }}
                />
                <kbd className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">
                  ⌘K
                </kbd>
              </div>
            </div>

            {/* Navigation */}
            <nav className="flex-1 space-y-6 px-4 py-2">
              {navigation.map((section) => (
                <div key={section.section}>
                  <h3 className="mb-2 px-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    {section.section}
                  </h3>
                  <ul className="space-y-1">
                    {section.items.map((item) => {
                      const isActive = location.pathname === item.href;
                      return (
                        <li key={item.name}>
                          <Link
                            to={item.href}
                            onClick={closeMenu}
                            className={cn(
                              "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                              isActive
                                ? "bg-accent text-accent-foreground"
                                : "text-foreground hover:bg-accent hover:text-accent-foreground",
                            )}
                          >
                            <item.icon className="h-4 w-4" />
                            {item.name}
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              ))}
            </nav>

            {/* Pro Tip */}
            <div className="mx-4 mb-4 rounded-lg bg-muted p-3">
              <p className="text-xs text-muted-foreground">
                <strong>Pro Tip:</strong> Upload PDFs, Word docs, or text files
                to get started!
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
