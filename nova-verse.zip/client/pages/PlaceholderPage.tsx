import { FileText } from "lucide-react";

interface PlaceholderPageProps {
  title: string;
  description: string;
}

export default function PlaceholderPage({
  title,
  description,
}: PlaceholderPageProps) {
  return (
    <div className="flex-1 p-4 md:p-8 overflow-auto">
      <div className="mx-auto max-w-4xl">
        <div className="flex flex-col items-center justify-center min-h-80 md:min-h-96 text-center space-y-4 md:space-y-6">
          <div className="rounded-full bg-muted p-6 md:p-8">
            <FileText className="h-8 w-8 md:h-12 md:w-12 text-muted-foreground" />
          </div>
          <div className="space-y-2">
            <h1 className="text-xl md:text-2xl font-bold text-foreground">
              {title}
            </h1>
            <p className="text-muted-foreground max-w-md text-sm md:text-base px-4">
              {description}
            </p>
          </div>
          <div className="rounded-lg bg-muted p-4 max-w-md mx-4">
            <p className="text-xs md:text-sm text-muted-foreground">
              This page is coming soon! Continue prompting to add content here.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
