import { DocumentUpload } from "@/components/DocumentUpload";
import { FeatureCards } from "@/components/FeatureCards";
import { AboutSection } from "@/components/AboutSection";

export default function Index() {
  return (
    <div className="flex-1 overflow-auto">
      <div className="p-4 md:p-8">
        <div className="mx-auto max-w-6xl">
          {/* Header */}
          <div className="mb-6 md:mb-8">
            <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
              Welcome to Study-Aid Generator
            </h1>
            <p className="text-muted-foreground text-sm md:text-base">
              Upload your documents and let AI transform them into interactive
              study materials
            </p>
          </div>

          {/* Upload Area */}
          <div className="mb-8 md:mb-12">
            <DocumentUpload />
          </div>

          {/* Feature Cards */}
          <div className="mb-16">
            <FeatureCards />
          </div>
        </div>
      </div>

      {/* About Section */}
      <AboutSection />
    </div>
  );
}
